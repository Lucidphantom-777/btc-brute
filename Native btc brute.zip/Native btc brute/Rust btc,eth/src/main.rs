use anyhow::Result;
use bip39::{Language, Mnemonic};
use bitcoin::bip32::{DerivationPath, Xpriv};
use bitcoin::network::Network;
use bitcoin::secp256k1::Secp256k1;
use bitcoin::{Address, PrivateKey, PublicKey};
use clap::Parser;
use ethers_core::types::Address as EthAddress;
use rand::Rng;
use reqwest::Client;
use std::sync::Arc;
use std::time::Instant;
use tiny_keccak::{Hasher, Keccak};
use tokio::sync::{Mutex, Semaphore};
use tokio::time::Duration;

#[derive(Parser)]
struct Args {
    #[arg(short, long, default_value_t = 500)]
    concurrent: usize,
    #[arg(short, long, default_value = "found_wallets.txt")]
    output: String,
    #[arg(short, long, default_value_t = 12)]
    words: usize,
}

fn derive_btc_address(seed: &[u8]) -> Result<String> {
    let secp = Secp256k1::new();
    let master = Xpriv::new_master(Network::Bitcoin, seed)?;
    let path: DerivationPath = "m/44'/0'/0'/0/0".parse()?;
    let child = master.derive_priv(&secp, &path)?;
    let secret = child.private_key;
    let priv_key = PrivateKey::new(secret, Network::Bitcoin);
    let pubkey = PublicKey::from_private_key(&secp, &priv_key);
    let address = Address::p2pkh(&pubkey, Network::Bitcoin);
    Ok(address.to_string())
}

fn derive_eth_address(seed: &[u8]) -> Result<String> {
    let secp = Secp256k1::new();
    let master = Xpriv::new_master(Network::Bitcoin, seed)?;
    let path: DerivationPath = "m/44'/60'/0'/0/0".parse()?;
    let child = master.derive_priv(&secp, &path)?;
    let secret = child.private_key;
    let priv_key = PrivateKey::new(secret, Network::Bitcoin);
    let pubkey = PublicKey::from_private_key(&secp, &priv_key);
    let uncompressed = pubkey.inner.serialize_uncompressed();
    let mut hasher = Keccak::v256();
    hasher.update(&uncompressed[1..]);
    let mut output = [0u8; 32];
    hasher.finalize(&mut output);
    let addr = EthAddress::from_slice(&output[12..]);
    Ok(format!("0x{}", hex::encode(addr.as_bytes())))
}

async fn check_btc_balance(client: &Client, address: &str) -> f64 {
    let url = format!("https://blockchain.info/q/addressbalance/{}", address);
    match client.get(&url).send().await {
        Ok(resp) if resp.status().is_success() => {
            if let Ok(text) = resp.text().await {
                if let Ok(balance_sat) = text.parse::<f64>() {
                    return balance_sat / 1e8;
                }
            }
        }
        _ => {}
    }
    0.0
}

async fn check_eth_balance(client: &Client, address: &str) -> f64 {
    let payload = serde_json::json!({
        "jsonrpc": "2.0",
        "method": "eth_getBalance",
        "params": [address, "latest"],
        "id": 1
    });
    let url = "https://cloudflare-eth.com";
    match client.post(url).json(&payload).send().await {
        Ok(resp) if resp.status().is_success() => {
            if let Ok(json) = resp.json::<serde_json::Value>().await {
                if let Some(result) = json.get("result").and_then(|v| v.as_str()) {
                    if let Ok(balance_hex) = u64::from_str_radix(&result[2..], 16) {
                        return balance_hex as f64 / 1e18;
                    }
                }
            }
        }
        _ => {}
    }
    0.0
}

async fn worker(
    client: Arc<Client>,
    semaphore: Arc<Semaphore>,
    output_file: Arc<Mutex<tokio::fs::File>>,
    attempt_counter: Arc<Mutex<u64>>,
    hit_counter: Arc<Mutex<u64>>,
    word_count: usize,
) {
    let _permit = semaphore.acquire().await.unwrap();

    let entropy_len = match word_count {
        12 => 16,
        24 => 32,
        _ => 16,
    };
    let mut entropy = vec![0u8; entropy_len];
    rand::thread_rng().fill(&mut entropy[..]);

    let mnemonic = match Mnemonic::from_entropy_in(Language::English, &entropy) {
        Ok(m) => m,
        Err(_) => return,
    };
    let phrase = mnemonic.to_string();
    let seed = mnemonic.to_seed("");

    let btc_addr = match derive_btc_address(&seed) {
        Ok(addr) => addr,
        Err(_) => return,
    };
    let eth_addr = match derive_eth_address(&seed) {
        Ok(addr) => addr,
        Err(_) => return,
    };

    let (btc_balance, eth_balance) = tokio::join!(
        check_btc_balance(&client, &btc_addr),
        check_eth_balance(&client, &eth_addr)
    );

    {
        let mut counter = attempt_counter.lock().await;
        *counter += 1;
    }

    if btc_balance > 0.0 || eth_balance > 0.0 {
        {
            let mut hit = hit_counter.lock().await;
            *hit += 1;
        }
        let output_line = format!(
            "Mnemonic: {}\nBTC: {} ({} BTC)\nETH: {} ({} ETH)\n\n",
            phrase, btc_addr, btc_balance, eth_addr, eth_balance
        );
        let mut file = output_file.lock().await;
        use tokio::io::AsyncWriteExt;
        let _ = file.write_all(output_line.as_bytes()).await;
        let _ = file.flush().await;
        println!("\n[+] HIT! {}", phrase);
    }
}

#[tokio::main]
async fn main() -> Result<()> {
    let args = Args::parse();

        // ======== SIMPLE BANNER (works everywhere) ========
    println!("\n");
    println!("██╗     ██╗   ██╗ ██████╗██╗██████╗ ██████╗ ██╗  ██╗ █████╗ ███╗   ██╗████████╗ ██████╗ ███╗   ███╗   ███████╗███████╗███████╗");
    println!("██║     ██║   ██║██╔════╝██║██╔══██╗██╔══██╗██║  ██║██╔══██╗████╗  ██║╚══██╔══╝██╔═══██╗████╗ ████║   ╚════██║╚════██║╚════██║");
    println!("██║     ██║   ██║██║     ██║██║  ██║██████╔╝███████║███████║██╔██╗ ██║   ██║   ██║   ██║██╔████╔██║█████╗ ██╔╝    ██╔╝    ██╔╝");
    println!("██║     ██║   ██║██║     ██║██║  ██║██╔═══╝ ██╔══██║██╔══██║██║╚██╗██║   ██║   ██║   ██║██║╚██╔╝██║╚════╝██╔╝    ██╔╝    ██╔╝ ");
    println!("███████╗╚██████╔╝╚██████╗██║██████╔╝██║     ██║  ██║██║  ██║██║ ╚████║   ██║   ╚██████╔╝██║ ╚═╝ ██║      ██║     ██║     ██║  ");
    println!("╚══════╝ ╚═════╝  ╚═════╝╚═╝╚═════╝ ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝    ╚═════╝ ╚═╝     ╚═╝      ╚═╝     ╚═╝     ╚═╝  ");
    println!("                                                                                                                              ");
    println!("\n");
    // ==================================================
    
    let semaphore = Arc::new(Semaphore::new(args.concurrent));
    let client = Arc::new(Client::new());
    let output_file = Arc::new(Mutex::new(
        tokio::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(&args.output)
            .await?,
    ));
    let attempt_counter = Arc::new(Mutex::new(0u64));
    let hit_counter = Arc::new(Mutex::new(0u64));
    let word_count = args.words;

    let start_time = Instant::now();

    let num_workers = args.concurrent * 2;
    for _ in 0..num_workers {
        let client = client.clone();
        let semaphore = semaphore.clone();
        let output_file = output_file.clone();
        let attempt_counter = attempt_counter.clone();
        let hit_counter = hit_counter.clone();
        tokio::spawn(async move {
            loop {
                worker(
                    client.clone(),
                    semaphore.clone(),
                    output_file.clone(),
                    attempt_counter.clone(),
                    hit_counter.clone(),
                    word_count,
                )
                .await;
            }
        });
    }

    let stats_handle = tokio::spawn({
        let attempt_counter = attempt_counter.clone();
        let hit_counter = hit_counter.clone();
        async move {
            let mut interval = tokio::time::interval(Duration::from_secs(2));
            loop {
                interval.tick().await;
                let elapsed = start_time.elapsed().as_secs_f64();
                let attempts = *attempt_counter.lock().await;
                let hits = *hit_counter.lock().await;
                let rate = attempts as f64 / elapsed;
                print!(
                    "\r[+] Attempts: {}  Hits: {}  Elapsed: {:.1}s  Rate: {:.0} mnemonics/s",
                    attempts, hits, elapsed, rate
                );
                use std::io::Write;
                std::io::stdout().flush().unwrap();
            }
        }
    });

    tokio::signal::ctrl_c().await?;
    println!("\nShutting down...");

    stats_handle.abort();
    tokio::time::sleep(Duration::from_millis(100)).await;

    let attempts = *attempt_counter.lock().await;
    let hits = *hit_counter.lock().await;
    let elapsed = start_time.elapsed().as_secs_f64();
    println!("Final: {} attempts, {} hits in {:.1}s", attempts, hits, elapsed);
    Ok(())
}