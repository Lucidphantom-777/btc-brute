# install rust 

curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source ~/.cargo/env
rustup default stable 


rustup default stable

cargo new btc_brute --bin
cd btc_brute

# Ubuntu/Debian
sudo apt install pkg-config libssl-dev
sudo apt update
sudo apt install -y pkg-config libssl-dev build-essential curl 

# Fedora
sudo dnf install pkgconf openssl-devel

# Arch
sudo pacman -S pkg-config openssl

cargo build --release
./target/release/btc_brute --concurrent 1000