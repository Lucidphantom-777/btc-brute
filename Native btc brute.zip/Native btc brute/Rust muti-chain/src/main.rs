
use anyhow::Result;
use bip39::{Language, Mnemonic};
use bitcoin::bip32::{DerivationPath, Xpriv};
use bitcoin::network::Network;
use bitcoin::secp256k1::Secp256k1;
use bitcoin::{Address, PrivateKey, PublicKey};
use clap::Parser;
use ed25519_dalek::SigningKey;
use ethers_core::types::Address as EthAddress;
use rand::Rng;
use reqwest::Client;
use sha2::{Digest, Sha256};
use std::sync::Arc;
use std::time::{Duration, Instant};
use tiny_keccak::{Hasher, Keccak};
use tokio::sync::{Mutex, Semaphore};

#[derive(Parser)]
struct Args {
    #[arg(short, long, default_value_t = 800)]
    concurrent: usize,
    #[arg(short, long, default_value = "found_wallets.txt")]
    output: String,
    #[arg(short, long, default_value_t = 12)]
    words: usize,
}

// ---------- BTC ----------
fn derive_btc_address(seed: &[u8]) -> Result<String> {
    let secp = Secp256k1::new();
    let master = Xpriv::new_master(Network::Bitcoin, seed)?;
    let path: DerivationPath = "m/44'/0'/0'/0/0".parse()?;
    let child = master.derive_priv(&secp, &path)?;
    let secret = child.private_key;
    let priv_key = PrivateKey::new(secret, Network::Bitcoin);
    let pubkey = PublicKey::from_private_key(&secp, &priv_key);
    let address = Address::p2pkh(&pubkey, Network::Bitcoin);
    Ok(address.to_string())
}

// ---------- EVM (ETH, BSC, Polygon, Avalanche) ----------
fn derive_evm_address(seed: &[u8]) -> Result<String> {
    let secp = Secp256k1::new();
    let master = Xpriv::new_master(Network::Bitcoin, seed)?;
    let path: DerivationPath = "m/44'/60'/0'/0/0".parse()?;
    let child = master.derive_priv(&secp, &path)?;
    let secret = child.private_key;
    let priv_key = PrivateKey::new(secret, Network::Bitcoin);
    let pubkey = PublicKey::from_private_key(&secp, &priv_key);
    let uncompressed = pubkey.inner.serialize_uncompressed();
    let mut hasher = Keccak::v256();
    hasher.update(&uncompressed[1..]);
    let mut output = [0u8; 32];
    hasher.finalize(&mut output);
    let addr = EthAddress::from_slice(&output[12..]);
    Ok(format!("0x{}", hex::encode(addr.as_bytes())))
}

// ---------- TRON (manual base58check) ----------
fn derive_tron_address(seed: &[u8]) -> Result<String> {
    let secp = Secp256k1::new();
    let master = Xpriv::new_master(Network::Bitcoin, seed)?;
    let path: DerivationPath = "m/44'/195'/0'/0/0".parse()?;
    let child = master.derive_priv(&secp, &path)?;
    let secret = child.private_key;
    let priv_key = PrivateKey::new(secret, Network::Bitcoin);
    let pubkey = PublicKey::from_private_key(&secp, &priv_key);
    let uncompressed = pubkey.inner.serialize_uncompressed();
    let mut hasher = Keccak::v256();
    hasher.update(&uncompressed[1..]);
    let mut hash = [0u8; 32];
    hasher.finalize(&mut hash);
    let hash20 = &hash[12..];
    let mut payload = vec![0x41];
    payload.extend_from_slice(hash20);
    let checksum = Sha256::digest(&Sha256::digest(&payload));
    let checksum_bytes = &checksum[0..4];
    payload.extend_from_slice(checksum_bytes);
    Ok(bs58::encode(payload).into_string())
}

// ---------- Solana (ed25519-dalek 2.x) ----------
fn derive_solana_address(seed: &[u8]) -> Result<String> {
    let secret_bytes: [u8; 32] = seed[0..32]
        .try_into()
        .map_err(|_| anyhow::anyhow!("Seed too short"))?;
    let signing_key = SigningKey::from_bytes(&secret_bytes);
    let verifying_key = signing_key.verifying_key();
    let pubkey_bytes = verifying_key.to_bytes();
    Ok(bs58::encode(pubkey_bytes).into_string())
}

// ---------- Balance checkers ----------
async fn check_btc_balance(client: &Client, address: &str) -> f64 {
    let url = format!("https://blockchain.info/q/addressbalance/{}", address);
    match client.get(&url).send().await {
        Ok(resp) if resp.status().is_success() => {
            if let Ok(text) = resp.text().await {
                if let Ok(balance_sat) = text.parse::<f64>() {
                    return balance_sat / 1e8;
                }
            }
        }
        _ => {}
    }
    0.0
}

async fn check_evm_balance(client: &Client, address: &str, rpc: &str) -> f64 {
    let payload = serde_json::json!({
        "jsonrpc": "2.0",
        "method": "eth_getBalance",
        "params": [address, "latest"],
        "id": 1
    });
    match client.post(rpc).json(&payload).send().await {
        Ok(resp) if resp.status().is_success() => {
            if let Ok(json) = resp.json::<serde_json::Value>().await {
                if let Some(result) = json.get("result").and_then(|v| v.as_str()) {
                    if let Ok(balance_hex) = u64::from_str_radix(&result[2..], 16) {
                        return balance_hex as f64 / 1e18;
                    }
                }
            }
        }
        _ => {}
    }
    0.0
}

async fn check_tron_balance(client: &Client, address: &str) -> f64 {
    let url = format!("https://api.trongrid.io/v1/accounts/{}", address);
    match client.get(&url).send().await {
        Ok(resp) if resp.status().is_success() => {
            if let Ok(json) = resp.json::<serde_json::Value>().await {
                if let Some(data) = json.get("data").and_then(|d| d.get(0)) {
                    if let Some(balance_sun) = data.get("balance").and_then(|b| b.as_u64()) {
                        return balance_sun as f64 / 1_000_000.0;
                    }
                }
            }
        }
        _ => {}
    }
    0.0
}

async fn check_solana_balance(client: &Client, address: &str) -> f64 {
    let payload = serde_json::json!({
        "jsonrpc": "2.0",
        "method": "getBalance",
        "params": [address],
        "id": 1
    });
    let url = "https://api.mainnet-beta.solana.com";
    match client.post(url).json(&payload).send().await {
        Ok(resp) if resp.status().is_success() => {
            if let Ok(json) = resp.json::<serde_json::Value>().await {
                if let Some(result) = json.get("result").and_then(|r| r.get("value")) {
                    if let Some(balance_lamports) = result.as_u64() {
                        return balance_lamports as f64 / 1e9;
                    }
                }
            }
        }
        _ => {}
    }
    0.0
}

// ---------- USDT token balances (ERC-20, TRC-20) ----------
const USDT_ETH: &str = "0xdAC17F958D2ee523a2206206994597C13D831ec7";
const USDT_BSC: &str = "0x55d398326f99059fF775485246999027B3197955";
const USDT_POLYGON: &str = "0xc2132D05D31c914a87C6611C10748AEb04B58e8F";
const USDT_AVALANCHE: &str = "0x9702230A8Ea53601f5cD2dc00fDBc13d4dF4A8c7";
const USDT_TRON: &str = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";

async fn check_erc20_balance(client: &Client, address: &str, token: &str, rpc: &str) -> f64 {
    let addr_clean = address.trim_start_matches("0x");
    let data = format!("0x70a08231{}", format!("{:0>64}", addr_clean));
    let payload = serde_json::json!({
        "jsonrpc": "2.0",
        "method": "eth_call",
        "params": [{"to": token, "data": data}, "latest"],
        "id": 1
    });
    match client.post(rpc).json(&payload).send().await {
        Ok(resp) if resp.status().is_success() => {
            if let Ok(json) = resp.json::<serde_json::Value>().await {
                if let Some(result) = json.get("result").and_then(|v| v.as_str()) {
                    if let Ok(balance_hex) = u128::from_str_radix(&result[2..], 16) {
                        return balance_hex as f64 / 1_000_000.0;
                    }
                }
            }
        }
        _ => {}
    }
    0.0
}

async fn check_trc20_balance(client: &Client, address: &str, token: &str) -> f64 {
    let url = format!("https://api.trongrid.io/v1/accounts/{}/tokens", address);
    match client.get(&url).send().await {
        Ok(resp) if resp.status().is_success() => {
            if let Ok(json) = resp.json::<serde_json::Value>().await {
                if let Some(data) = json.get("data").and_then(|d| d.as_array()) {
                    for item in data {
                        if let Some(token_id) = item.get("tokenId").and_then(|v| v.as_str()) {
                            if token_id == token {
                                if let Some(balance_str) = item.get("balance").and_then(|v| v.as_str()) {
                                    if let Ok(balance) = balance_str.parse::<f64>() {
                                        return balance / 1_000_000.0;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        _ => {}
    }
    0.0
}

// ---------- Worker ----------
async fn worker(
    client: Arc<Client>,
    semaphore: Arc<Semaphore>,
    output_file: Arc<Mutex<tokio::fs::File>>,
    attempt_counter: Arc<Mutex<u64>>,
    hit_counter: Arc<Mutex<u64>>,
    word_count: usize,
) {
    let _permit = semaphore.acquire().await.unwrap();

    let entropy_len = match word_count {
        12 => 16,
        24 => 32,
        _ => 16,
    };
    let mut entropy = vec![0u8; entropy_len];
    rand::thread_rng().fill(&mut entropy[..]);

    let mnemonic = match Mnemonic::from_entropy_in(Language::English, &entropy) {
        Ok(m) => m,
        Err(_) => return,
    };
    let phrase = mnemonic.to_string();
    let seed = mnemonic.to_seed("");

    let btc_addr = derive_btc_address(&seed).unwrap_or_default();
    let evm_addr = derive_evm_address(&seed).unwrap_or_default();
    let tron_addr = derive_tron_address(&seed).unwrap_or_default();
    let sol_addr = derive_solana_address(&seed).unwrap_or_default();

    let (
        btc_bal, eth_bal, bsc_bal, polygon_bal, avax_bal, tron_bal, sol_bal,
        eth_usdt, bsc_usdt, polygon_usdt, avax_usdt, tron_usdt,
    ) = tokio::join!(
        check_btc_balance(&client, &btc_addr),
        check_evm_balance(&client, &evm_addr, "https://cloudflare-eth.com"),
        check_evm_balance(&client, &evm_addr, "https://bsc-dataseed1.binance.org"),
        check_evm_balance(&client, &evm_addr, "https://polygon-rpc.com"),
        check_evm_balance(&client, &evm_addr, "https://api.avax.network/ext/bc/C/rpc"),
        check_tron_balance(&client, &tron_addr),
        check_solana_balance(&client, &sol_addr),
        check_erc20_balance(&client, &evm_addr, USDT_ETH, "https://cloudflare-eth.com"),
        check_erc20_balance(&client, &evm_addr, USDT_BSC, "https://bsc-dataseed1.binance.org"),
        check_erc20_balance(&client, &evm_addr, USDT_POLYGON, "https://polygon-rpc.com"),
        check_erc20_balance(&client, &evm_addr, USDT_AVALANCHE, "https://api.avax.network/ext/bc/C/rpc"),
        check_trc20_balance(&client, &tron_addr, USDT_TRON),
    );

    {
        let mut counter = attempt_counter.lock().await;
        *counter += 1;
    }

    if btc_bal > 0.0 || eth_bal > 0.0 || bsc_bal > 0.0 || polygon_bal > 0.0
        || avax_bal > 0.0 || tron_bal > 0.0 || sol_bal > 0.0
        || eth_usdt > 0.0 || bsc_usdt > 0.0 || polygon_usdt > 0.0 || avax_usdt > 0.0 || tron_usdt > 0.0
    {
        {
            let mut hit = hit_counter.lock().await;
            *hit += 1;
        }
        let output_line = format!(
            "Mnemonic: {}\n\
             BTC: {} ({} BTC)\n\
             ETH: {} ({} ETH) | USDT: {}\n\
             BSC: {} ({} BNB) | USDT: {}\n\
             Polygon: {} ({} MATIC) | USDT: {}\n\
             Avalanche: {} ({} AVAX) | USDT: {}\n\
             TRON: {} ({} TRX) | USDT: {}\n\
             Solana: {} ({} SOL)\n\n",
            phrase,
            btc_addr, btc_bal,
            evm_addr, eth_bal, eth_usdt,
            evm_addr, bsc_bal, bsc_usdt,
            evm_addr, polygon_bal, polygon_usdt,
            evm_addr, avax_bal, avax_usdt,
            tron_addr, tron_bal, tron_usdt,
            sol_addr, sol_bal
        );
        let mut file = output_file.lock().await;
        use tokio::io::AsyncWriteExt;
        let _ = file.write_all(output_line.as_bytes()).await;
        let _ = file.flush().await;
        println!("\n[+] HIT! {}", phrase);
    }
}

// ---------- Main ----------
#[tokio::main(flavor = "multi_thread", worker_threads = 16)]
async fn main() -> Result<()> {
    let args = Args::parse();

    // ======== SIMPLE BANNER (works everywhere) ========
    println!("\n");
    println!("██╗     ██╗   ██╗ ██████╗██╗██████╗ ██████╗ ██╗  ██╗ █████╗ ███╗   ██╗████████╗ ██████╗ ███╗   ███╗   ███████╗███████╗███████╗");
    println!("██║     ██║   ██║██╔════╝██║██╔══██╗██╔══██╗██║  ██║██╔══██╗████╗  ██║╚══██╔══╝██╔═══██╗████╗ ████║   ╚════██║╚════██║╚════██║");
    println!("██║     ██║   ██║██║     ██║██║  ██║██████╔╝███████║███████║██╔██╗ ██║   ██║   ██║   ██║██╔████╔██║█████╗ ██╔╝    ██╔╝    ██╔╝");
    println!("██║     ██║   ██║██║     ██║██║  ██║██╔═══╝ ██╔══██║██╔══██║██║╚██╗██║   ██║   ██║   ██║██║╚██╔╝██║╚════╝██╔╝    ██╔╝    ██╔╝ ");
    println!("███████╗╚██████╔╝╚██████╗██║██████╔╝██║     ██║  ██║██║  ██║██║ ╚████║   ██║   ╚██████╔╝██║ ╚═╝ ██║      ██║     ██║     ██║  ");
    println!("╚══════╝ ╚═════╝  ╚═════╝╚═╝╚═════╝ ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝    ╚═════╝ ╚═╝     ╚═╝      ╚═╝     ╚═╝     ╚═╝  ");
    println!("                                                                                                                              ");
    println!("\n");
    // ==================================================

    let client = Client::builder()
        .pool_max_idle_per_host(1000)
        .timeout(Duration::from_secs(5))
        .build()?;

    let semaphore = Arc::new(Semaphore::new(args.concurrent));
    let client = Arc::new(client);
    let output_file = Arc::new(Mutex::new(
        tokio::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(&args.output)
            .await?,
    ));
    let attempt_counter = Arc::new(Mutex::new(0u64));
    let hit_counter = Arc::new(Mutex::new(0u64));
    let word_count = args.words;

    let start_time = Instant::now();

    let mut worker_handles = Vec::new();
    for _ in 0..(args.concurrent * 2) {
        let client = client.clone();
        let semaphore = semaphore.clone();
        let output_file = output_file.clone();
        let attempt_counter = attempt_counter.clone();
        let hit_counter = hit_counter.clone();
        let handle = tokio::spawn(async move {
            loop {
                worker(
                    client.clone(),
                    semaphore.clone(),
                    output_file.clone(),
                    attempt_counter.clone(),
                    hit_counter.clone(),
                    word_count,
                )
                .await;
            }
        });
        worker_handles.push(handle);
    }

    let stats_handle = tokio::spawn({
        let attempt_counter = attempt_counter.clone();
        let hit_counter = hit_counter.clone();
        async move {
            let mut interval = tokio::time::interval(Duration::from_secs(2));
            loop {
                interval.tick().await;
                let elapsed = start_time.elapsed().as_secs_f64();
                let attempts = *attempt_counter.lock().await;
                let hits = *hit_counter.lock().await;
                let rate = attempts as f64 / elapsed;
                print!(
                    "\r[+] Attempts: {}  Hits: {}  Elapsed: {:.1}s  Rate: {:.0} mnemonics/s",
                    attempts, hits, elapsed, rate
                );
                std::io::Write::flush(&mut std::io::stdout()).unwrap();
            }
        }
    });

    tokio::signal::ctrl_c().await?;
    println!("\nShutting down...");

    for handle in worker_handles {
        handle.abort();
    }
    stats_handle.abort();
    tokio::time::sleep(Duration::from_millis(10)).await;

    let attempts = *attempt_counter.lock().await;
    let hits = *hit_counter.lock().await;
    let elapsed = start_time.elapsed().as_secs_f64();
    println!("Final: {} attempts, {} hits in {:.1}s", attempts, hits, elapsed);
    Ok(())
}