# 🔐 BIP39 Wallet Brute-Force Tool (Educational)

> **⚠️ FOR EDUCATIONAL AND SECURITY RESEARCH PURPOSES ONLY**  
> This tool demonstrates how cryptocurrency wallets are derived from BIP39 mnemonics and how on‑chain balances are queried.  
> **Randomly guessing valid mnemonics to find funded wallets is practically impossible** (odds ≈ 1/2^128 for 12‑word seeds).  
> Unauthorised access to others' wallets is illegal. The user bears full legal responsibility.  
> The author assumes no liability for misuse.

---

## ✨ Features

- **Multi‑chain support** – BTC, ETH, BNB, Solana, TRX, Polygon, Avalanche.
- **High performance** – multiprocessing + asyncio + uvloop for maximum throughput.
- **Batch requests** – EVM chains use JSON‑RPC batching to reduce HTTP overhead.
- **Early pruning** – checks BTC and ETH first; skips other chains unless a positive balance is found (configurable).
- **Token balance checks** – optionally check ERC‑20, BEP‑20, TRC‑20, and SPL tokens (USDC, USDT, etc.).
- **Configurable** – all settings can be tuned via `config.json` or environment variables.
- **Real‑time stats** – shows attempts, hits, elapsed time, and mnemonics/second.
- **Output** – found wallets are saved in JSON format with full details (mnemonic, addresses, private keys, balances).

---

## 📦 Requirements

- Python 3.8 or higher
- `pip` (Python package installer)

---

## 🛠️ Installation

1. **Clone or download** this repository.

2. **Install dependencies**:

```bash
pip install -r requirements.txt
```

The requirements.txt file contains:

```
aiohttp
uvloop
bip-utils
```

---

🚀 Usage

Basic run (default settings)

```bash
python btc.py
```

🚀 Quick Start

```bash
# Clone or download the repository
git clone https://github.com/yourusername/wallet-scanner.git
cd wallet-scanner

# Install dependencies
pip install -r requirements.txt

# Run with default settings (all 7 chains, token checks off)
python wallet_scanner.py
```


This will start with:

· All 7 chains enabled
· Token checks disabled (for speed)
· 4 producers, 8 consumers (auto‑tuned)
· BTC and ETH as priority chains (early pruning)

Using environment variables for tuning

```bash
export PRODUCERS=8
export THREADS=12
export MAX_CONCURRENT_REQUESTS=200
export BATCH_SIZE=100
export CHAINS=btc,eth,bnb,polygon,avalanche
export PRIORITY_CHAINS=btc,eth
export CHECK_TOKENS=false
python b.py
```

Using config.json

Create a config.json file in the same directory:

```json
{
  "producers": 6,
  "threads": 10,
  "chains": ["btc", "eth", "bnb", "sol", "trx", "polygon", "avalanche"],
  "priority_chains": ["btc", "eth"],
  "check_tokens": false,
  "max_concurrent_requests": 150,
  "batch_size": 100,
  "word_count": 12,
  "btc_address_type": "legacy",
  "output_file": "found_wallets.txt"
}
```

Then run without environment overrides:

```bash
python btc.py
```

---

⚙️ Configuration Options

Setting Environment Variable Default Description
producers PRODUCERS cpu_count() * 2 Number of CPU‑bound processes generating mnemonics.
threads THREADS 8 Number of I/O‑bound consumer processes checking balances.
chains CHAINS [btc,eth,bnb,sol,trx,polygon,avalanche] List of blockchains to check.
priority_chains PRIORITY_CHAINS [btc,eth] Chains checked first; if all zero, skip others (set to [] to check all).
check_tokens CHECK_TOKENS false If true, also query token balances (slower).
max_concurrent_requests MAX_CONCURRENT_REQUESTS 50 Maximum concurrent HTTP requests per chain.
batch_size BATCH_SIZE 100 Number of addresses per EVM batch request.
word_count WORD_COUNT 12 BIP39 mnemonic length (12 or 24).
btc_address_type BTC_ADDRESS_TYPE legacy legacy (P2PKH) or bech32 (SegWit).
output_file OUTPUT_FILE found_wallets.txt File to save results.
token_contracts (not env) Built‑in list Token contract addresses per chain.
token_decimals (not env) Built‑in list Decimals for each token contract.

---

📄 Output Format

When a wallet with positive balance is found, it is saved to the output file (default found_wallets.txt) as a JSON object per line:

```json
{
  "timestamp": "2026-07-17T02:43:38.123456",
  "mnemonic": "abandon ability able about above absent ...",
  "chains": {
    "btc": {
      "address": "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa",
      "private_key": "5HpHagT65TZzG1PH3CSu63k8DbpvD8s5ip4nEB3kEsreAnchuDf",
      "balance": 0.00000000
    },
    "eth": {
      "address": "0x742d35Cc6634C0532925a3b844Bc454e4438f44e",
      "private_key": "0x4c0883a69102937d6231471b5dbb6204fe5129617082792ae468d01a3f362318",
      "balance": 0.00000000
    }
    // ... more chains
  }
}
```

If token checks are enabled, an additional "token_balances" field is added.

---

🧠 How It Works

1. Producers generate random BIP39 mnemonics (12 or 24 words) using secrets.token_bytes and derive all addresses via bip_utils.
2. The derived data is placed into a multiprocessing.Queue.
3. Consumers take batches of addresses and send balance requests in parallel using aiohttp + uvloop.
4. EVM chains (ETH, BNB, Polygon, Avalanche) use JSON‑RPC batching – up to batch_size addresses per HTTP request.
5. Priority chains are checked first; if no positive balance is found, the remaining chains are skipped (saves I/O).
6. If a positive balance is found, the wallet is saved to the output file.

---

⚡ Performance Tips

· Disable token checks (CHECK_TOKENS=false) for a 2‑3× speed boost.
· Limit chains to only those you are interested in, especially if some are slow (e.g., BTC and Solana).
· Increase concurrency (MAX_CONCURRENT_REQUESTS up to 200–300) but monitor for RPC errors.
· Adjust batch size – BATCH_SIZE=100 is a good balance; too large may hit RPC limits.
· Use private RPC endpoints (Infura, Alchemy) for faster and more reliable responses.
· Match producers to CPU cores – producers = cpu_count() * 2 is a good start.

---

⚠️ Disclaimer

THIS TOOL IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
The probability of randomly generating a BIP39 mnemonic that corresponds to a wallet with any significant balance is so low that it is effectively impossible within any human‑timescale.
Do not use this tool for any illegal or unethical purpose. The developer assumes no responsibility for any misuse, damage, or legal consequences arising from the use of this software.

By using this tool, you acknowledge that you are solely responsible for ensuring your actions comply with all applicable laws and regulations.

---

📝 License

This project is licensed under the MIT License – see the LICENSE file for details.

---

🙏 Acknowledgements

· bip_utils – BIP39 and BIP44 implementation.
· aiohttp – asynchronous HTTP client.
· uvloop – fast event loop for asyncio.
· Public RPC endpoints used for balance checks (see code for list).

---

Happy learning! Use this knowledge to strengthen blockchain security, not to compromise it.

